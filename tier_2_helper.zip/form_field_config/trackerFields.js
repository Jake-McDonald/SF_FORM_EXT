var trackerFields;
trackerFields = {
    "trackerURL": "https://docs.google.com/forms/d/e/1FAIpQLScUdkxnCW0OES8BQkItvnpQ_oOYhjdSHFA4bE4Oo1cIxB55vw/viewform?usp=pp_url",
    "tierTwoName": "entry.181847084",
    "tierOneName": "entry.1319484688",
    "caseNumber": "entry.1320601144",
    "agentInquiry": "entry.1125842625",
    "tierTwoActionsTaken": "entry.1555734172",
    "resourceProvided": "entry.689876397",
    "outcome": "entry.1065249769",
    "contactMethod":"entry.837488045"
};